%% Ntokozo Radebe RDBNTO016 Milestone 1
%% Symbolic Variables
% To begin with the modeling, symbolic variables are defined, followed by defining 
% the generalised coordinates. There are three coordinates in which the lander 
% can move and rotate, namely x, y and theta.

syms F1 F2 L1 L2 m dL Izz Jzz g

syms x y theta dx dy dtheta ddx ddy ddtheta 

syms Qx Qy Qtheta

q = [x; y; theta];
dq = [dx; dy; dtheta];
ddq = [ddx; ddy; ddtheta];

%% Position and Velocity of Lander
% The position of the lander is defined about its Body and about the Inertial. 
% It is assumed that the lander does not rotate, hence there are no rotation matrix. 
% It will be shown later that the rotation is accounted by the thruster forces. 
% The position of the lander about its Body is defined according to its dimentions 
% relative to the COM. The position of the lander about the Inertial is the coordinates 
% of the inertial added to the lander's body vector.

rLander_B = [0; dL+L2/2; 0]; %Position of lander wrt body

rLander_I = [x; y; 0] + rLander_B; %Postion of lander wrt to inertial
 
vLander = jacobian(rLander_I,q)*dq; %Linear velocity
wLander = dtheta; %Angular velocity
%% Kinetic Energy and Potential Energy
% The lander has both translational and rotational kinetic energy. Since the 
% lander is in a xy plane, it rotates about the z-axis. For the potential energy, 
% the distance in the y axis is only considered since it defines the height above 
% the ground.

T_Lander = 1/2*m*transpose(vLander)*vLander + 1/2*Izz*wLander^2;

V_Lander = m*g*rLander_I(2); %only the second element in the inertial position of the lander is used

%% Lagrangian
% There is no need to determine the lagrangian, it was soley for understanding 
% the step-by-step procedure of determing the EOM. In the place of the lagrangian, 
% the manipulator equation is used.

L = T_Lander - V_Lander;
%% Force positions
% As mentioned before, the forces will account for the rotation, hence the rotation 
% matrix about z is used to express forces in the body and the inertial frame. 
% In addition, the body frame position of the forces is rotated, not the position 
% of the inertia frame position. The same applies when input forces, however, 
% the inertial coordinates [x; y; 0] are not added to the input forces because 
% they are only accounted in the position vectors of the forces. Furthermore, 
% the generalised forces are then determined and represented according to the 
% generalised coordinates.

RotI_B = Rotz(theta);
RotB_I = transpose(RotI_B);

%Position of the forces
r_f1_B = [-L1/2; 0; 0]; %Position of F1 wrt to Body 
r_f1_I = [x; y; 0] + RotB_I*r_f1_B; %Position of F1 wrt to Inertial

r_f2_B = [L1/2; 0; 0]; %Position of F1 wrt to Body
r_f2_I = [x; y; 0] + RotB_I*r_f2_B; %Position of F1 wrt to Inertial

%Input forces wrt inertia
f1_B = F1*[0; 1; 0]; %force act on the y-axis wrt Body
f1_I = RotB_I*f1_B; %force act on the y-axis wrt Inertial

f2_B = F2*[0; 1; 0]; %force act on the y-axis wrt Body
f2_I = RotB_I*f2_B; %force act on the y-axis wrt Inertial

%%Generalised Forces
Qx = transpose(f1_I)*jacobian(r_f1_I,x) + transpose(f2_I)*jacobian(r_f2_I,x);
Qy = transpose(f1_I)*jacobian(r_f1_I,y) + transpose(f2_I)*jacobian(r_f2_I,y);
Qtheta = transpose(f1_I)*jacobian(r_f1_I,theta) + transpose(f2_I)*jacobian(r_f2_I,theta);
Q = [Qx; Qy; Qtheta];
Q = simplify(Q);

%% Define Mass Matrix

M = hessian(T_Lander,dq);
%% Define Mass Matrix Deriv

dM = sym(zeros(length(M),length(M)));
for i=1:length(M)
    for j=1:length(M)
        dM(i,j) = jacobian(M(i,j),q)*dq;
    end
end
dM = simplify(dM);
%% Define Gravity Matrix

G = jacobian(V_Lander,q);
G = simplify(G);
%% Define Coriolis Matrix

C = dM*dq - transpose(jacobian(T_Lander,q));
C = simplify(C);
%% Using the Manipulator Eqution to determine the EOM
% In this step, the manipulator equation is used instead of the lagrangian equation 
% as the manipulator equation also accounts for the generalised forces.

ManipulatorE = M*ddq + C + transpose(G) == Q;
%% Determing g and Izz and dL
% To determine g, both F1 and F2 are set to zero. This models the lander as 
% being in free-fall, thus the only force acted on it is the gravitational force. 
% As a result, the linear acceleration of of the lander as it falls is the gravitational 
% acceleration of the planet. The value of the acceleration (ddy) is obtained 
% from the simulation and the mean function is used to determine the average value 
% of the grativational acceleration. This is governed by Newtown 2nd law, where 
% Fnet = ma, F1 + F2 - m*g = ma, this then leads to g=-a, ultimately, g=a
% 
% To determine Izz, F1 and F2 must be non-zero and non-equal. Izz is dependant 
% on the angular acceleration. As expected, when F1 and F2 are non-zero and non-equal, 
% and F1 must be greater that F2 for counter-clockwise rotation as stated in the 
% milestone description, therefore cause the lander to rotate about the z-axis 
% with and angle theta. The angular acceleration is determined from the simulation 
% and an average value is determined and substituted in the Izz equation. This 
% is governed by the equation Torque = Izz * alpha, where alpha is theta double 
% dot. This further expressed to L1/2*F1 - L1/2*F2 = Izz*alpha. Since Izz must 
% be a positive value, the absolute function is applied on both sides of the eqautions.
% 
% To determined dL, the second moment of inertia Jzz is defined using the parallex 
% axis theorem equation, then equate it to the value of avarage value of Izz determined. 

%GravitationalAcc = mean(ddy_out.signals.values)
%AngularAcc = mean(ddth_out.signals.values)
EOM = subs(ManipulatorE, [L1, L2, m], [6, 8, 4000]);
ddq = solve(EOM,ddq); %these are the acceleration equations with respect to their generalised coordinates.


g = (solve(EOM(2:2), g)); %g is made the subject of the formula to determine it
Izz = abs(solve(EOM(3:3), Izz)); %Izz is made the subject of the formula to determine it


%Extracting the simulink values to determine g, Izz, and dL
x_ = x_out.signals.values;
y_ = y_out.signals.values;
dy_ = dy_out.signals.values;
theta_ = th.signals.values;
ddy_ = ddy_out.signals.values;
%dtheta = dth.signals.values;
ddtheta_ = ddth_out.signals.values;
F1sim = F1_sim.signals.values;
F2sim = F2_sim.signals.values;

%To determine g, set F1 and F2 to zero
g_avg = vpa(simplify(subs(g, [F1 F2 ddy], [0 0 mean(ddy_)])));

%To determine Izz, F1 and F2 must be non-equal and non-zero
Izz_avg = vpa(subs(Izz, [F1 F2 ddtheta], [150 15 mean(ddtheta_)]));


Jzz = 1/12*m*(L1^2+L2^2) + m*dL^2 == Izz_avg; %Parallel axis theorem
Jzz = vpa(subs(Jzz, [m L1 L2], [4000 6 8]));
dL = solve(Jzz, dL);


fprintf("G value = %.3f m/s^2",g_avg)
fprintf("Izz value = %.3f kg.mm^2",Izz_avg)
fprintf("dL value = %.3f m",dL)

%% 
% If the values are set in the simulink simulation the following code below 
% is used. It is commented out as it produdes the same results as the code above, 
% only when the conditions of the code about are applied in the simulation.

%if (F1sim + F2sim == 0)
%    g_avg = subs(g,ddy,mean(ddy))

%else
    %g_avg = subs(g,[theta, F1, F2, ddy, m],[mean(theta), F1sim, F2sim, mean(ddy), 4000])
    %Izz_avg = subs(Izz,[L1, L2, F1, F2, ddtheta], [6, 8, F1sim, F2sim, mean(ddtheta)])
    %Torque = Izz*ddtheta == F2*L1/2 - F1*L1/2
    %Torque_value = subs(Torque,[F1,F2,L1,L2,m,ddtheta],[0,150,6,8,4000,mean(ddtheta)])
    %dL = solve(Torque_value,dL)
    %dL_ = simplify(dL)
%end
%% Helper Functions

function A = Rotz(th)
A = [cos(th)   -sin(th) 0;...
    sin(th)  cos(th) 0;...
    0        0        1];
end
%%