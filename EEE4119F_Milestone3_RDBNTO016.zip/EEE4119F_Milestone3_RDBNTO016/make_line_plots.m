% simulate a Simulink model multiple times, plotting the results
% note that it expects the simulink model to send x, y, th, and dy to the
% matlab workspace as "Structure with Time"
function make_line_plots(n, model_name)

    figure(1); grid on; hold all;
    xlabel('x bottom [m]'); ylabel('y bottom [m]')
    title('Line plot of position over time')

    plot([-1 -1 1 1], [0 5 5 0]) % the landing pad

    figure(2); grid on; hold all;
    xlabel('time [s]'); ylabel('Lander angle [rad]')
    title('Angle of lander over time')

    figure(3); grid on; hold all;
    xlabel('time [s]'); ylabel('Lander speed [m/s]')
    title('Vertical lander speed over time')

    for i = 1:n
        seed = num2str(randi(1000000));
        set_param([model_name, '/rngSeedForLander'], 'Value', seed);
        sim(model_name)  % simulate the model in simulink

        figure(1)
        plot(x.signals.values, y.signals.values)

        figure(2)
        plot(x.time, th.signals.values)

        figure(3)
        plot(x.time, dy.signals.values)

        safely_landed(y.signals.values, dy.signals.values, th.signals.values);
    end

    % show the plots
    shg
end
