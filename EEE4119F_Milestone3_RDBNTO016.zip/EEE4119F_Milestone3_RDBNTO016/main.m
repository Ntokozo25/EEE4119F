close all
%rngSeed = 0;

%% make an animation
% You'll probably only want to run this twice - once right now, and again
% after your controller works :)
sim('LanderModelV2_RDBNTO016');  % tell simulink to simulate the model
make_animation(x.time, x.signals.values, y.signals.values, th.signals.values, dy.signals.values, 10)

% note the .time and .signals.values syntax for unpacking a Structure with
% Time
%GravitationalAcceleration_of_planet = mean(ddy_out.signals.values)
%AngularAcceleration = mean(ddth_out.signals.values)

%% check whether you succeeded
safely_landed(y.signals.values, dy.signals.values, th.signals.values)

%% make line plots
% this runs your simulation multiple times and plots some useful
% quantities. You'll probably want to use this a lot

make_line_plots(3, 'LanderModelV2_RDBNTO016')
