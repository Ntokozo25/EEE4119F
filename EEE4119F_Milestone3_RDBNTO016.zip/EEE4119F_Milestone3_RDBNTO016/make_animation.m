% warning - this is an incredibly crude animation and shouldn't be taken
% too seriously. It's mostly just for fun.
% it expects t, x, y, th and dy as regular arrays
% fps is the number of frames per second the animation should run at
% there are two timings happening here: one to make the animation run in
% real time, and one to set the number of frames shown per second
function make_animation(t, x, y, th, dy, fps)
    L1 = 6.0;
    L2 = 8.0;
    
    dt = t(2) - t(1);

    figure; hold all; shg
    coords = [min(x)-L1 max(x)+L1 -5 max(y)+L2];

    cur_t = 0;
    tic;
    for i = 1:length(x)
        % only make a frame every 0.1 seconds
        cur_t = cur_t + dt;
        if cur_t < 1/fps
            continue  % skip to the next for loop iteration
        else
            cur_t = 0;
        end
        
        clf
        
        % a horizontal line for the ground
        plot([coords(1) coords(2)], [0, 0])
        hold on
        
        % a landing pad at x = 0 = 0
        plot([-1 -1 1 1], [0 5 5 0])
        
        % draw the rocket
        add_rocket(x(i), y(i), th(i), L1, L2)
        
        title(['t = ', num2str(i*dt),...
               's, dy = ', num2str(round(dy(i))), 'm/s'])

        axis(coords)
        grid on
        
        % make the plot update in real time
        t_loop = toc;
        if t_loop < 1/fps
            pause(1/fps - t_loop)
        end
        tic;
    end
end


function add_rocket(x, y, th, L1, L2)
    % this is a total hack. I really just don't know matlab's plotting
    % facilities very well, though I think it's annotation bits aren't
    % super good
    x_coords = [x x-sin(th)*L1];
    y_coords = [y y+cos(th)*L2];

    ha = annotation('arrow');  % store the arrow information in ha
    ha.Parent = gca;           % associate the arrow the the current axes
    ha.X = x_coords;           % the location in data units
    ha.Y = y_coords;

    ha.LineWidth  = 1;         % make the arrow bolder for the picture
    ha.HeadWidth  = 30;
    ha.HeadLength = 30;
end
