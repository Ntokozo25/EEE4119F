%% Milestone 2
% From milestone 1, the lander was successfully model and differential equations 
% were determined using model steps. The above code provides logical process on 
% how the values were determined. The parameters that were determined in milestone 
% 1 was the gravitational acceleration of the unknown planet, the mass moment 
% of inertia of the lander, and lastly, the offset distance of the lander from 
% the COM. These parameters were determined to be:
% 
% |*G value = 9.869 m/s^2*|
% 
% |*Izz value = 56253.949 kg.mm^2*|
% 
% |*dL = 2.394 m*|
% 
% Below is the summary of the approach that took place in milestone 1:
close all; clear; clc;
syms x y th dx dy dth ddx ddy ddth F1 F2 'real'
syms m L1 L2 dL g Izz 'real'
q   = [x; y; th];
dq  = [dx; dy; dth];
ddq = [ddx; ddy; ddth];
%% Positions, Velocity and Energies
% position
rBody = [x; y];
% velocity
vBody = jacobian(rBody,q)*dq;

% Kinetic energy
Ttot = 0.5*m*transpose(vBody)*vBody + 0.5*Izz*dth^2;
Ttot = simplify(Ttot);
% Potential Energy
Vtot = m*g*rBody(2);

%% Manipulator equation terms
% Mass matrix
M = simplify(hessian(Ttot, dq));

dM = sym(zeros(size(M)));
for i = 1:size(dM, 1)
    for j = 1:size(dM, 2)
        dM(i,j) = jacobian(M(i,j), q) * dq;
    end
    
end
dM = simplify(dM);

% Coriolis Matrix
C = dM*dq - transpose(jacobian(Ttot, q));
C = simplify(C);
% Gravity Matrix
G = simplify(jacobian(Vtot, q)');

%% Q input matrix

% rotation matrix
R = [ cos(th) -sin(th)
      sin(th)  cos(th)];
% thrust positions
r1 = [x; y] + R*[-L1/2; -L2/2-dL];
r2 = [x; y] + R*[L1/2; -L2/2-dL];

% input force with respect to inertia
f1 = R * [0; F1];
f2 = R * [0; F2];

% Q matrix calculatiom
Q1 = simplify(f1' * jacobian(r1, q))';
Q2 = simplify(f2' * jacobian(r2, q))';



%% 
% In this milestone, the task is to Linearise the model to determined the state 
% matrices. These state matrices are crucial in determining the control of the 
% lander and its thrust forces. Below, a logic approach is provided on how to 
% linearize the model and determine the state matrices. This process involves 
% 4 steps:
% 
% *#1. Operating Point Selection:* First, an operating point (also called an 
% equilibrium point) is chosen around which the system will be linearized. This 
% operating point represents the state of the system where the linearization is 
% performed.

%Setting equalibrium state values
% The operating point is x = dx = y = dy = th = dth = 0 and hovering, so the 
% thrust is shared between the two rotors


%% 
% *#2. Linearization Process:* At the chosen operating point, the nonlinear 
% equations describing the system's dynamics are linearized by approximating them 
% with their first-order Taylor series expansion. This expansion involves finding 
% the Jacobian matrix, which contains partial derivatives of the system's dynamics 
% with respect to its state variables.
u = [F1; F2];

B = jacobian(Q1 + Q2, [F1; F2]);%B matrix

%% 
% *#3. Obtaining Linearized Equations:* Using the Jacobian matrix, the nonlinear 
% differential equations are linearized to obtain a set of linear ordinary differential 
% equations (ODEs) or state-space equations. These linearized equations describe 
% the small-signal behavior of the system around the chosen operating point.
% solving for accelerations
acceleration_eqns = simplify(M \ (-C - G + B*u));
% state variables derivatives
dyn = [acceleration_eqns; dq];

%% Linearized model Matrices

% A matrix
A = jacobian(dyn, [dq.', q.']);
A = subs(A, [dq.', q.', u.'], [0,0,0,0,0,0,m*g/2,m*g/2]);

% B matrix
B = jacobian(dyn, u.');
B = subs(B, [dq.',q.',u.'],[0,0,0,0,0,0,m*g/2,m*g/2]);

% Model parameters substitution
m_ = 4000;
L1_ = 6;
L2_ = 8;
I_ = 56253.949;
g_ = 9.869;

% Subsitute to get numerical A and B
A = double(subs(A, [m,L1,L2,Izz,g], [m_,L1_,L2_,I_,g_]));
B = double(subs(B, [m,L1,L2,Izz,g], [m_,L1_,L2_,I_,g_]));

C = [0 1 0 0 0 0; 0 0 0 0 1 0; 0 0 0 0 0 1];
D = [];

states = {'dx' 'dy' 'dth' 'x' 'y' 'th'};
inputs = {'u1' 'u2'};
outputs = {'dy'  'y' 'th'};

sys_ss = ss(A, B, C, D, 'statename', states,...
                        'inputname', inputs,...
                        'outputname', outputs);

%%
% *#4. Control Design:* With the linearized equations, standard linear control 
% design techniques such as pole placement, LQR (Linear Quadratic Regulator), 
% or PID (Proportional-Integral-Derivative) control can be applied to design controllers 
% for the system. Applying LQR is as follows:
Q = 5000*eye(6);
Q(5,5) = 450;
R = 1/100*eye(2);

% calculate LQR gain

K = lqr(A, B, Q, R);

%% Closed Loop System
Ac = [(A-B*K)];
Bc = [B];
Cc = [C];
Dc = [D];
sys_cl = ss(Ac, B, C, D, 'statename', states,...
                            'inputname', inputs,...
                            'outputname', outputs);
%% Plot Response

t = 0:0.1:200;
r = 2*ones(length(t), 2);
[y,t,x] = lsim(sys_cl, r, t);

% plot the position states
plot(t, y);
legend(["x"; "y"; "th"]);
title('Step Response with LQR Control')
